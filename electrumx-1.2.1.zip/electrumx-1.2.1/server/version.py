# Server name and protocol versions

VERSION = 'ElectrumX 1.2.1'
PROTOCOL_MIN = '0.9'
PROTOCOL_MAX = '1.1'
